%%%  PURE QUEEN KNOWLEDGEBASE DARLING

%% use examples:
	%  lyrics("lyrics you want to search",X).
	% dont forget to use "" for the lyrics
	% please always put the lyrics on the right side of the query.
	% if the line your'e going to search for ends with a comma just ommit it
	%  i.e.  Sends shivers down my spine, -> "Sends shivers down my spine"

	%%%%%%%%%%%% KB %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%CRAZY LITTLE THING CALLED LOVE
lyrics("This thing called love","Crazy Little Thing Called Love").
lyrics("I just can't handle it","Crazy Little Thing Called Love").
lyrics("I must get round to it","Crazy Little Thing Called Love").
lyrics("I ain't ready","Crazy Little Thing Called Love").
lyrics("This thing (this thing) called love (called love)","Crazy Little Thing Called Love").
lyrics("It cries (like a baby) in a cradle all night","Crazy Little Thing Called Love").
lyrics("It swings (ooh, ooh), it jives (ooh, ooh)","Crazy Little Thing Called Love").
lyrics("It shakes all over like a jelly fish","Crazy Little Thing Called Love").
lyrics("I kinda like it","Crazy Little Thing Called Love").
lyrics("Crazy little thing called love","Crazy Little Thing Called Love").
lyrics("There goes my baby","Crazy Little Thing Called Love").
lyrics("She knows how to rock-n-roll","Crazy Little Thing Called Love").
lyrics("She drives me crazy","Crazy Little Thing Called Love").
lyrics("She gives me hot and cold fever","Crazy Little Thing Called Love").
lyrics("She leaves me in a cool, cool sweat","Crazy Little Thing Called Love").
lyrics("I gotta be cool, relax, get hip","Crazy Little Thing Called Love").
lyrics("Get on my tracks","Crazy Little Thing Called Love").
lyrics("Take a back seat, hitch-hike","Crazy Little Thing Called Love").
lyrics("And take a long ride on my motorbike","Crazy Little Thing Called Love").
lyrics("Until I'm ready","Crazy Little Thing Called Love").
lyrics("I gotta be cool, relax, get hip","Crazy Little Thing Called Love").
lyrics("And get on my tracks","Crazy Little Thing Called Love").
lyrics("Take a back seat, hitch-hike","Crazy Little Thing Called Love").
lyrics("And take a long ride on my motorbike","Crazy Little Thing Called Love").
lyrics("Until I'm ready (Ready Freddie)","Crazy Little Thing Called Love").
lyrics("Crazy little thing called love [repeat to fade] ","Crazy Little Thing Called Love").

%BOHEMIAN RHAPSODY
lyrics("Too late, my time has come","Bohemian Rhapsody").
lyrics("Sends shivers down my spine","Bohemian Rhapsody").
lyrics("Body's aching all the time.","Bohemian Rhapsody").
lyrics("Goodbye, everybody, I've got to go","Bohemian Rhapsody").
lyrics("Gotta leave you all behind and face the truth.","Bohemian Rhapsody").
lyrics("Mama, ooh (any way the wind blows)","Bohemian Rhapsody").
lyrics("I don't wanna die","Bohemian Rhapsody").
lyrics("I sometimes wish I'd never been born at all.","Bohemian Rhapsody").
lyrics("I see a little silhouetto of a man","Bohemian Rhapsody").
lyrics("Scaramouche, Scaramouche, will you do the Fandango?","Bohemian Rhapsody").
lyrics("Thunderbolt and lightning","Bohemian Rhapsody").
lyrics("Very, very frightening me.","Bohemian Rhapsody").
lyrics("(Galileo) Galileo.","Bohemian Rhapsody").
lyrics("(Galileo) Galileo","Bohemian Rhapsody").
lyrics("Galileo Figaro","Bohemian Rhapsody").
lyrics("Magnifico-o-o-o-o.","Bohemian Rhapsody").
lyrics("I'm just a poor boy, nobody loves me.","Bohemian Rhapsody").
lyrics("He's just a poor boy from a poor family","Bohemian Rhapsody").
lyrics("Spare him his life from this monstrosity.","Bohemian Rhapsody").
lyrics("Easy come, easy go, will you let me go?","Bohemian Rhapsody").
lyrics("Bismillah! No, we will not let you go. (Let him go!)","Bohemian Rhapsody").
lyrics("Bismillah! We will not let you go. (Let him go!)","Bohemian Rhapsody").
lyrics("Bismillah! We will not let you go. (Let me go!)","Bohemian Rhapsody").
lyrics("Will not let you go. (Let me go!)","Bohemian Rhapsody").
lyrics("Never let you go (Never, never, never, never let me go)","Bohemian Rhapsody").
lyrics("Oh oh oh oh","Bohemian Rhapsody").
lyrics("No, no, no, no, no, no, no","Bohemian Rhapsody").
lyrics("Oh, mama mia, mama mia (Mama mia, let me go.)","Bohemian Rhapsody").
lyrics("Beelzebub has a devil put aside for me, for me, for me.","Bohemian Rhapsody").
lyrics("So you think you can stone me and spit in my eye?","Bohemian Rhapsody").
lyrics("So you think you can love me and leave me to die?","Bohemian Rhapsody").
lyrics("Oh, baby, can't do this to me, baby","Bohemian Rhapsody").
lyrics("Just gotta get out, just gotta get right outta here.","Bohemian Rhapsody").
lyrics("(Ooooh, ooh yeah, ooh yeah)","Bohemian Rhapsody").
lyrics("Nothing really matters","Bohemian Rhapsody").
lyrics("Anyone can see","Bohemian Rhapsody").
lyrics("Nothing really matters","Bohemian Rhapsody").
lyrics("Nothing really matters to me.","Bohemian Rhapsody").

%I WANT IT ALL
lyrics("Adventure seeker on an empty street","I Want It All").
lyrics("Just an alley creeper, light on his feet","I Want It All").
lyrics("A young fighter screaming, with no time for doubt","I Want It All").
lyrics("With the pain and anger can't see a way out","I Want It All").
lyrics("It ain't much I'm asking, I heard him say","I Want It All").
lyrics("Gotta find me a future move out of my way","I Want It All").
lyrics("I want it all, I want it all, I want it all, and I want it now","I Want It All").
lyrics("Listen all you people, come gather round","I Want It All").
lyrics("I gotta get me a game plan, gotta shake you to the ground","I Want It All").
lyrics("Just give me what I know is mine","I Want It All").
lyrics("People do you hear me, just give me the sign","I Want It All").
lyrics("It ain't much I'm asking, if you want the truth","I Want It All").
lyrics("Here's to the future for the dreams of youth","I Want It All").
lyrics("I'm a man with a one track mind","I Want It All").
lyrics("So much to do in one life time (people do you hear me)","I Want It All").
lyrics("Not a man for compromise and where's and why's and living lies","I Want It All").
lyrics("So I'm living it all, yes I'm living it all","I Want It All").
lyrics("And I'm giving it all, and I'm giving it all","I Want It All").
lyrics("It ain't much I'm asking, if you want the truth","I Want It All").
lyrics("Here's to the future, hear the cry of youth","I Want It All").
lyrics("I want it all, I want it all, I want it all, and I want it now","I Want It All").
lyrics("I want it all, I want it all, I want it all, and I want it now","I Want It All").

%I WANT TO BREAK FREE
lyrics("I want to break free","I Want To Break Free").
lyrics("I want to break free","I Want To Break Free").
lyrics("I want to break free from your lies","I Want To Break Free").
lyrics("You're so self satisfied I don't need you","I Want To Break Free").
lyrics("I've got to break free","I Want To Break Free").
lyrics("God knows, God knows I want to break free.","I Want To Break Free").
lyrics("I've fallen in love","I Want To Break Free").
lyrics("I've fallen in love for the first time","I Want To Break Free").
lyrics("And this time I know it's for real","I Want To Break Free").
lyrics("I've fallen in love, yeah","I Want To Break Free").
lyrics("God knows, God knows I've fallen in love.","I Want To Break Free").
lyrics("It's strange but it's true","I Want To Break Free").
lyrics("I can't get over the way you love me like you do","I Want To Break Free").
lyrics("But I have to be sure","I Want To Break Free").
lyrics("When I walk out that door","I Want To Break Free").
lyrics("Oh how I want to be free, baby","I Want To Break Free").
lyrics("Oh how I want to be free","I Want To Break Free").
lyrics("Oh how I want to break free.","I Want To Break Free").
lyrics("But life still goes on","I Want To Break Free").
lyrics("I can't get used to, living without, living without","I Want To Break Free").
lyrics("Living without you by my side","I Want To Break Free").
lyrics("I don't want to live alone, hey","I Want To Break Free").
lyrics("God knows, got to make it on my own","I Want To Break Free").
lyrics("So baby can't you see","I Want To Break Free").
lyrics("I've got to break free.","I Want To Break Free").
lyrics("I've got to break free","I Want To Break Free").
lyrics("I want to break free, yeah","I Want To Break Free").
lyrics("I want, I want, I want, I want to break free.","I Want To Break Free").

%LOVE OF MY LIFE
lyrics("Love of my life, you've hurt me.","Love Of My Life").
lyrics("You've broken my heart","Love Of My Life").
lyrics("And now you leave me.","Love Of My Life").
lyrics("Love of my life, can't you see?","Love Of My Life").
lyrics("Bring it back, bring it back","Love Of My Life").
lyrics("Don't take it away from me","Love Of My Life").
lyrics("Because you don't know","Love Of My Life").
lyrics("What it means to me.","Love Of My Life").
lyrics("Love of my life, don't leave me.","Love Of My Life").
lyrics("You've taken my love","Love Of My Life").
lyrics("(all my love)","Love Of My Life").
lyrics("You now desert me.","Love Of My Life").
lyrics("Love of my life, can't you see?","Love Of My Life").
lyrics("(please bring it back)","Love Of My Life").
lyrics("Bring it back, bring it back","Love Of My Life").
lyrics("Don't take it away from me","Love Of My Life").
lyrics("Because you don't know","Love Of My Life").
lyrics("What it means to me.","Love Of My Life").
lyrics("You will remember","Love Of My Life").
lyrics("When this is blown over","Love Of My Life").
lyrics("And everything's all by the way.","Love Of My Life").
lyrics("When I grow older","Love Of My Life").
lyrics("I will be there at your side","Love Of My Life").
lyrics("To remind you how I still love you.","Love Of My Life").
lyrics("I still love you.","Love Of My Life").
lyrics("Back, hurry back.","Love Of My Life").
lyrics("Please, bring it back home to me","Love Of My Life").
lyrics("Because you don't know","Love Of My Life").
lyrics("What it means to me.","Love Of My Life").
lyrics("Love of my life.","Love Of My Life").

%WE ARE THE CHAMPIONS
lyrics("I've paid my dues","We Are The Champions").
lyrics("Time after time.","We Are The Champions").
lyrics("I've done my sentence","We Are The Champions").
lyrics("But committed no crime.","We Are The Champions").
lyrics("And bad mistakes‒","We Are The Champions").
lyrics("I've made a few.","We Are The Champions").
lyrics("I've had my share of sand kicked in my face","We Are The Champions").
lyrics("But I've come through.","We Are The Champions").
lyrics("We are the champions, my friends.","We Are The Champions").
lyrics("And we'll keep on fighting 'til the end.","We Are The Champions").
lyrics("We are the champions.","We Are The Champions").
lyrics("We are the champions.","We Are The Champions").
lyrics("No time for losers","We Are The Champions").
lyrics("'Cause we are the champions of the world.","We Are The Champions").
lyrics("I've taken my bows","We Are The Champions").
lyrics("And my curtain calls.","We Are The Champions").
lyrics("You brought me fame and fortune, and everything that goes with it.","We Are The Champions").
lyrics("I thank you all.","We Are The Champions").
lyrics("But it's been no bed of roses","We Are The Champions").
lyrics("No pleasure cruise.","We Are The Champions").
lyrics("I consider it a challenge before the whole human race","We Are The Champions").
lyrics("And I ain't gonna lose.","We Are The Champions").
lyrics("We are the champions, my friends.","We Are The Champions").
lyrics("And we'll keep on fighting 'til the end.","We Are The Champions").
lyrics("We are the champions.","We Are The Champions").
lyrics("We are the champions.","We Are The Champions").
lyrics("No time for losers","We Are The Champions").
lyrics("'Cause we are the champions of the world.","We Are The Champions").
lyrics("We are the champions, my friends.","We Are The Champions").
lyrics("And we'll keep on fighting 'til the end.","We Are The Champions").
lyrics("We are the champions.","We Are The Champions").
lyrics("We are the champions.","We Are The Champions").
lyrics("No time for losers","We Are The Champions").
lyrics("'Cause we are the champions of the world.","We Are The Champions").

%WE WILL ROCK YOU
lyrics("Buddy you're a boy make a big noise","We Are The Champions").
lyrics("Playin' in the street gonna be a big man some day","We Are The Champions").
lyrics("You got mud on yo' face","We Are The Champions").
lyrics("You big disgrace","We Are The Champions").
lyrics("Kickin' your can all over the place","We Are The Champions").
lyrics("Singin'","We Are The Champions").
lyrics("We will we will rock you","We Are The Champions").
lyrics("Buddy you're a young man hard man","We Are The Champions").
lyrics("Shoutin' in the street gonna take on the world some day","We Are The Champions").
lyrics("You got blood on yo' face","We Are The Champions").
lyrics("You big disgrace","We Are The Champions").
lyrics("Wavin' your banner all over the place","We Are The Champions").
lyrics("(Sing it!)","We Are The Champions").
lyrics("Buddy you're an old man poor man","We Are The Champions").
lyrics("Pleadin' with your eyes gonna make you some peace some day","We Are The Champions").
lyrics("You got mud on your face","We Are The Champions").
lyrics("Big disgrace","We Are The Champions").
lyrics("Somebody better put you back into your place","We Are The Champions").
lyrics("(Everybody)","We Are The Champions").
lyrics("(Alright) ","We Are The Champions").


