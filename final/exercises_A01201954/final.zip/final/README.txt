exercise 3 inmplemented in Java concurrent

exercise 5 implemented in Prolog logic
